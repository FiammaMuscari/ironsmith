#!/usr/bin/env bash
set -o pipefail
source /workspace/shared/ironsmith-card-env.sh
cd /workspace/shared/ironsmith-card-campaign
cargo test --locked --no-fail-fast -p ironsmith-compiler-runtime --lib \
 --test power_filtered_prevention --test target_type_coordination --test landwalk_block_override --test dash_materialization \
 --test repeated_static_heads --test job_select_materialization --test graveyard_additional_costs --test lossy_metadata \
 --test keyword_action_alternatives --test passive_noncombat_triggers --test filtered_discard_triggers --test cycle_discard_other_triggers \
 --test pack_tactics --test altair_ibn_laahad --test second_sunrise --test boseiju_channel --test venture_dispatch --test source_untap_triggers --test ward_source_power --test coordinated_stat_continuations -- --test-threads=2
